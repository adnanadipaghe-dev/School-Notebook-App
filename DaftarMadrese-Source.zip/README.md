دفتر مدرسه - پروژه اندروید

این پروژه با Android Gradle Plugin 8.7.3، Gradle 8.9 و Java/Kotlin JVM 17 تنظیم شده است.

برای ساخت APK از GitHub Actions و فایل build-apk.yml استفاده کنید.
